#include <stdio.h>
#include <stdlib.h>


typedef struct {
    int dia, mes, anio;
}eFecha;

typedef struct{
    char nombre[50];
    int legajo;
    char sexo;
    float sueldo;
    eFecha fechaIngreso;
    int isEmpty;
}eEmpleado;

void mostrarEmpleados(eEmpleado[],int);
void mostrarEmpleado(eEmpleado[],int);
void inicializarEmpleados(eEmpleado [],int tam);
int buscarLibre(eEmpleado [],int);
int buscarEmpleado(eEmpleado[],int,int);
void alta(eEmpleado[],int);
int menu();

int main()
{
    int salir=0;
    eEmpleado gente[50];
    inicializarEmpleados(gente,50);


    do{
        switch(menu())
            {
                case 1:
                printf("\n\nAlta\n");
                system("pause");
                break;

                case 2:
                printf("\n\Baja\n");
                system("pause");
                break;

                case 3:
                printf("\n\Modificacion\n");
                system("pause");
                break;

                case 4:
                printf("\n\Listar\n");
                system("pause");
                break;

                case 5:
                printf("\n\Ordenar\n");
                system("pause");
                break;

                case 6:
                printf("\n\Salir\n");
                system("pause");
                salir=1;

                break;

                default:
                printf("Error, reingrese numero \n");
                system("pause");

            }
    }while(salir!=1);

    return 0;
}

int menu()
{
        int opcion;
        system("cls");
        printf("-----BAUS.MENU-----\n\n");
        printf("1- Alta\n");
        printf("2- Baja\n");
        printf("3- Modificacion\n");
        printf("4- Listar\n");
        printf("5- Ordenar\n");
        printf("6- Salir");
        printf("\n\nSeleccione una opcion: ");
        scanf("%d", &opcion);

        return opcion;
}

void inicializarEmpleados(eEmpleado vec[], int tam)
{
    int i;
    for(i=0;i<tam;i++)
    {
        vec[i].isEmpty==-1;
    }
}
mostrarEmpleados(eEmpleado


    //printf("%s %d %c %.2f %d", eEmpleado.nombre,eEmpleado.legajo,eEmpleado.sexo,eEmpleado.sueldo,eEmpleado.fechaIngreso);
int buscarLibre(eEmpleado vec[],int tam)
{
    int index = -1;
    int i;
    for(i=0; i<tam; i++)
    {
        if(vec[i].isEmpty==0)
        {
            index = i;
            break;
        }
    }
    return index;
}

int buscarEmpleado(eEmpleado vec[], int tam, int legajo)
{
    int existe= 1;
    int i;
    for(i=0; i<tam; i++)
    {
        if(legajo==eEmpleado[i].legajo)
    }


}
void alta(eEmpleado vec[], int tam)
{
    eEmpleado nuevoEmpleado;
    int indice;
    int esta;
    int legajo;

    system("cls");
    indice=buscarLibre(vec,tam);
    if(indice==-1)
    {
        printf("\nEl sistema esta completo. No se puede dar de alta ningun otro empleado");
    }
    else
    {
        printf("Ingrese legajo: ");
        scanf("%d", %legajo);

        esta=buscarEmpleado(vec,tam,legajo);


    }
}

void mostrarEmpleado(eEmpleado vec[],int tam)
{
    printf("%d %s %c %2.f\n", legajo,nombre,sexo,sueldo)
}
