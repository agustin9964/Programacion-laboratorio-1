#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TAM 3

typedef struct{ //EJERCICIO DE RELACIONAMIENTO DE ESTRUCTURAS
    int id;
    char descripcion[51];
    int isEmpty;
}eSector;

//HAY RELACION DE UNO A UNO, DE UNO A MUCHOS, Y DE MUCHOS A MUCHOS
//


typedef struct {
    int dia, mes, anio;
}eFecha;

typedef struct{
    char nombre[50];
    int legajo;
    char sexo;
    float sueldo;
    eFecha fechaIngreso;
    int isEmpty;//SI ES IGUAL A 1 ES PORQUE ESTA LLENO.
    int idSector;
}eEmpleado;


int menu();//Muestra el esqueleto del menu
void inicializarEmpleados(eEmpleado [],int tam); //PIDE QUE TE CARGUE EMPLEADOS Y SI ESTA VACIO QUE SEA =1
int buscarLibre(eEmpleado [],int);  //BUSCA UN LUGAR LIBRE PARA PONER DATOS


void mostrarEmpleados(eEmpleado[],int);//MUESTRA A LOS EMPLEADOS
void mostrarEmpleado(eEmpleado); //hace un printf para listar los datos de un empleado


int buscarEmpleado(eEmpleado[],int,int); //
void alta(eEmpleado[],int);

void bajaEmpleado(eEmpleado[],int);

void ordenarPorNombre(eEmpleado[],int);

void modificar(eEmpleado[],int);

void harsectoreo(eSector[]);

int main()
{

    eSector sectores[]={1,"RRHH",0,2,"Sistemas",0,3,"Deposito",0};//SOLO SE PUEDE HACER CUANDO SE DECLARA
    //={{1,"RRHH",0},{2,"SISTEMAS,0},{3,"DEPOSITO",0}; OTRA FORMA, MAS VISUAL Y FACIL DE COMPRENDER DEL HARDCODEO DE ESTRUCTURA
    int salir=0;
    eEmpleado gente[50];
    inicializarEmpleados(gente,TAM);
    do{
        switch(menu())
            {
                case 1:
                printf("\n\nAlta\n");
                alta(gente,TAM);
                system("pause");
                break;

                case 2:
                printf("\n\Baja\n");
                bajaEmpleado(gente,TAM);
                system("pause");
                break;

                case 3:
                printf("\n\Modificacion\n");
                system("pause");
                break;

                case 4:
                printf("\n\Listar\n");
                mostrarEmpleados(gente,TAM);
                system("pause");
                break;

                case 5:
                printf("\n\Ordenar\n");
                ordenarPorNombre(gente,TAM);
                mostrarEmpleados(gente,TAM);
                system("pause");
                break;

                case 6:
                printf("\n\Salir\n");
                system("pause");
                salir=1;

                break;

                default:
                printf("Error, reingrese numero \n");
                system("pause");
            }
    }while(salir!=1);
    return 0;
}

int menu()//listo
{
        int opcion;
        system("cls");
        printf("-----BAUS.MENU-----\n\n");
        printf("1- Alta\n");
        printf("2- Baja\n");
        printf("3- Modificacion\n");
        printf("4- Listar\n");
        printf("5- Ordenar\n");
        printf("6- Salir");
        printf("\n\nSeleccione una opcion: ");
        scanf("%d", &opcion);

        return opcion;
}

void inicializarEmpleados(eEmpleado vec[], int tam)//listo
{
        for(int i=0; i< tam; i++)
    {
        vec[i].isEmpty =1;
    }
}

int buscarLibre(eEmpleado vec[],int tam)//listo
{
    int index=-1;
    for(int i=0;i<tam; i++)
    {
        if(vec[i].isEmpty== 1)
        {
            index= i;
            break;
        }
    }
    return index;
}

void mostrarEmpleados(eEmpleado vec[], int tam)
{
    system("cls");
    printf("-----EMPLEADOS LISTADOS----\n\n");
    printf("  LEGAJO  NOMBRE   SEXO   SUELDO   FECHA DE INGRESO \n\n");
    for(int i=0; i<tam; i++)
    {
         if(vec[i].isEmpty == 0 )
        {
            mostrarEmpleado(vec[i]);
        }
    }
}

void mostrarEmpleado(eEmpleado emp)
{
    printf("  %4d     %s     %c  %.2f    %02d/%02d/%4d \n", emp.legajo, emp.nombre, emp.sexo, emp.sueldo, emp.fechaIngreso.dia, emp.fechaIngreso.mes, emp.fechaIngreso.anio);
}

int buscarEmpleado(eEmpleado vec[], int tam, int legajo)
{
    int index=-1;

    for(int i= 0; i<tam ; i++)
    {
        if(vec[i].isEmpty==0 && vec[i].legajo==legajo)
        {
            index=i;
            break;
        }
    }
    return index;
}

void alta(eEmpleado vec[], int tam)
{
    eEmpleado nuevoEmpleado;
    int indice;
    int esta;
    int legajo;

    system("cls");
    printf("---ALTA EMPLEADOS---\n\n");

    indice=buscarLibre(vec,tam);

        if(indice== -1)
        {
            printf("\nEl sistema esta completo, no se pueden dar de alta mas empleados.\n");
        }
        else
        {
            printf("\nIngrese legajo del empleado: ");
            scanf("%d", &legajo);

            esta=buscarEmpleado(vec,tam,legajo);

            if(esta != -1)
            {
                printf("\nEl legajo %d ya esta dado de alta\n", legajo);
                mostrarEmpleado(vec[esta]);
            }
            else
            {
                nuevoEmpleado.isEmpty=0;
                nuevoEmpleado.legajo=legajo;

                printf("Ingrese nombre : ");
                fflush(stdin);
                gets(nuevoEmpleado.nombre);

                printf("Ingrese sexo: ");
                fflush(stdin);
                scanf("%c", &nuevoEmpleado.sexo);

                printf("Ingrese sueldo: ");
                fflush(stdin);
                scanf("%f", &nuevoEmpleado.sueldo);

                printf("Ingrese fecha de ingreso---D--M--A: ");
                fflush(stdin);
                scanf("%d %d %d", &nuevoEmpleado.fechaIngreso.dia, &nuevoEmpleado.fechaIngreso.mes, &nuevoEmpleado.fechaIngreso.anio);


                vec[indice]=nuevoEmpleado;
                printf("Alta exitosa.");
            }
        }
}

void bajaEmpleado(eEmpleado vec[],int tam)
{
    int legajo;
    int esta;

    char confirmar;
    system("cls");
    printf("---BAJA EMPLEADO---\n\n");

    printf("Ingrese legajo: ");
    scanf("%d", &legajo);

    esta=buscarEmpleado(vec,tam,legajo);

    if(esta== -1)
    {
        printf("El legajo %d no esta ingresado en el sistema.\n", legajo);
    }
    else
    {
        mostrarEmpleado(vec[esta]);

        printf("\nConfirmar baja? ");
        fflush(stdin);
        scanf("%c", &confirmar);
        if(confirmar=='s')
        {
            vec[esta].isEmpty =1;
            printf("\nSe ha ejecutado la baja ");
        }
        else
        {
            printf("\nSe ha cancelado la baja");
        }
    }
}

void ordenarPorNombre(eEmpleado emp[], int tam)
{
    for(int i = 0; i < tam-1; i++)
    {
        for(int j = i+1; j <tam; j++)
        {
            if(strcmp(emp[j].nombre,emp[i].nombre) < 0)
            {
                eEmpleado aux;
                aux = emp[i];
                emp[i] = emp[j];
                emp[j] = aux;
            }
            else if(strcmp(emp[j].nombre,emp[i].nombre) == 0)
            {
                if(emp[j].sueldo > emp[i].sueldo)
                {
                    eEmpleado aux;
                    aux = emp[i];
                    emp[i] = emp[j];
                    emp[j] = aux;
                }
                else if(emp[j].sueldo == emp[i].sueldo )
                {
                    if(emp[j].legajo > emp[i].legajo)
                    {
                        eEmpleado aux;
                        aux = emp[i];
                        emp[i] = emp[j];
                        emp[j] = aux;
                    }
                }
            }
        }
    }
}
void modificar(eEmpleado vec [],int tam)
{
    int esta;
    char confirmar;
    int legajo;
    int salir=0;

    system("cls");

    printf("---Modifica empleado---\n\n");

     printf("Ingrese legajo: ");
    scanf("%d", &legajo);

    esta=buscarEmpleado(vec,tam,legajo);

    if(esta== -1)
    {
        printf("El legajo %d no esta ingresado en el sistema.\n", legajo);
    }
    else
    {
        mostrarEmpleado(vec[esta]);

        do{
                printf("Confirmar modificacion? S/N");
                fflush(stdin);
                scanf("%c", confirmar);
                confirmar = tolower(confirmar);

            }while(confirmar!='s' && confirmar!='n');

            if(confirmar=='s')
            {
                do
                {
                case 1:

                system("pause");
                break;

                case 2:

                system("pause");
                break;

                case 3:
                system("pause");
                break;

                case 4:
                system("pause");
                break;

                case 5:
                system("pause");
                break;
                case 6:
                system("pause");
                break;

                case 7:
                printf("\n\Salir\n");
                system("pause");
                salir=1;
                break;

                default:
                printf("Error, reingrese numero valido\n");
                system("pause")
                }while(salir!=1)
                printf("Se ha realizado la modificacion\n\n");
            }
            else
            {
                printf("No se ha realizado la modificacion");
            }
    }

}
int menuModificacion()
{
        int opcion;
        system("cls");
        printf("-----Menu modificacion-----\n\n");
        printf("1- Legajo\n");
        printf("2- Nombre\n");
        printf("3- Sexo\n");
        printf("4- Sueldo\n");
        printf("5- Fecha de ingreso\n");
        printf("6- Sector");
        printf("7- Salir");
        printf("\n\nSeleccione una opcion: ");
        scanf("%d", &opcion);
        return opcion;
}

void harsectoreo(eSector sectores[])
{
    eSector nuevoSector;

    nuevoSector.id=1;
    strcpy(nuevoSector.descripcion,"RRHH");
    nuevoSector.isEmpty=0;
    sectores[0] = nuevoSector;

    nuevoSector.id=2;
    strcpy(nuevoSector.descripcion,"Sistemas");
    nuevoSector.isEmpty=0;
    sectores[1] = nuevoSector;

    sectores[2].id=3;
    strcpy(sectores[2].descripcion,"Administracion");
    sectores[2].isEmpty=0;

    sectores[3].id=4;
    strcpy(sectores[3].descripcion,"Compras");
    sectores[3].isEmpty=0;

    sectores[4].id=5;
    strcpy(sectores[4].descripcion,"Deposito");
    sectores[4].isEmpty=0;
}

//LISTAR TODOS LOS EMPLEADOS
//RECORRER EL ARRAY DE EMPLEADOS
//PIDE EL ID SECTOR
//DENTRO DEL ID SECTOR, RECORRE LOS DISTINTOS SECTORES QUE HAY
//CUANDO LO ENCUENTRA, MUESTRA EL NOMBRE DEL SECTOR
// for(i=0;i<100;i++)
// for(j=0;j<5;j++)
//if(emp[i].idSector==sec[j].id)
// %d ,emp[i].legajo
// %s ,emp[i].nombre
// %s ,sec[j].descripcion
//LISTAR LOS SECTORES POR EMPLEADO
